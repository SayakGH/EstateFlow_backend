const COMPANY_MASTER = {
  "Airde Real Estate": {
    name: "Airde Real Estate",
    address: "123, Tech Park, Sector 62, Noida, UP - 201301",
    phone: "+91 98765 43210",
    email: "contact@airderealestate.com",
  },
  "Airde Developers": {
    name: "Airde Developers",
    address: "45, Business Hub, MG Road, Bengaluru, KA - 560001",
    phone: "+91 91234 56789",
    email: "support@airdedevelopers.com",
  },
  "Sora Realtors": {
    name: "Sora Realtors",
    address: "78, Skyline Towers, Banjara Hills, Hyderabad, TS - 500034",
    phone: "+91 99887 66554",
    email: "info@sorarealtors.com",
  },
  "Unique Realcon": {
    name: "Unique Realcon",
    address: "10, Infinity Plaza, Salt Lake, Kolkata, WB - 700091",
    phone: "+91 90000 11122",
    email: "sales@uniquerealcon.com",
  },
};

module.exports = { COMPANY_MASTER };
